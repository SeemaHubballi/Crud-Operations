<!DOCTYPE html>
<html>
  <head>
    <title>Insert Employee records In Database</title>
<style>
form{
	border:1px solid black;
	margin-top:5%;
	border-radius:25px;
	width:40%;
        margin-left:25%;
}
</style>
  </head>

  <body>

    <form action="<?php echo site_url('employee/employee_form');?>" method="post">
         <center><u><h3> Enter following details </u></h3></center>
          <table align="center">
              <tr>
                <td>Employeen Id: </td>
                <td>
                  <?php echo form_input(array('id'=>'empid',
                                    'name'=>'empid',
                                    'placeholder'=>'Employee Id',
                                    'size'=>25));?>
                  </td>
               <tr>
                <td>Employee Name: </td>
                <td>
                  <?php echo form_input(array('id'=>'empname',
                                    'name'=>'empname',
                                    'placeholder'=>'Employee Name',
                                    'size'=>25));?>
                  </td>
                </tr>
                  <tr>
                    <td>Email Id: </td>
                    <td>
                      <?php echo form_input(array('id'=>'email',
                                        'name'=>'email',
                                        'placeholder'=>'Email Id',
                                        'size'=>25));?>
                      </td>
                    </tr>

                    <tr>
                      <td>Contact No: </td>
                      <td>
                        <?php echo form_input(array('id'=>'phno',
                                          'name'=>'phno',
                                          'placeholder'=>'Mobile no',
                                          'size'=>25));?>
                        </td>
                      </tr>

                      <tr>
                        <td>Address: </td>
                        <td>
                          <?php echo form_input(array('type'=>'textarea',
                                            'id'=>'address',
                                            'name'=>'address',
                                            'placeholder'=>'Address',
                                            'size'=>25));?>
                          </td>
                        </tr>
                  <tr>
                  <td>Date of joining: </td>
                  <td>
                    <?php echo form_input(array('id'=>'doj', 'type'=>'date',
                                      'name'=>'doj',
                                      'placeholder'=>'Date of joining',
                                      'size'=>25));?>
                    </td>
                  </tr>  

                        <tr>
                          <td></td>
                          <td>
                            <button type="submit" id="employee_submit">SAVE</button>
                          </td>
                        </tr>
                    </table>




                  </body>
                  </html>
