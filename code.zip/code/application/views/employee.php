<!DOCTYPE html>
<html>
  <head>
    <title>Select Employee records In Database</title>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <center><u><h2>Employee details</u></h2></center><br/>
            
  <table class="table">
    <thead>
      <tr>
        <th>Employee Id</th>
        <th>Employee Name</th>
        <th>Email Id</th>
        <th>Contact No</th>
        <th>Address</th>
        <th>Date of joining</th>
      </tr>
    </thead>
    <tbody>
       <?php foreach ($arrData as $row) { ?>
      <tr>
                <td><?php echo $row['empid'] ?></td>
                <td><?php echo $row['empname'] ?></td>
               
                <td><?php echo $row['email'] ?></td>
                <td><?php echo $row['phno']?></td>
                <td><?php echo $row['address'] ?></td>
		<td><?php echo $row['doj']?></td>
              </tr>
       <?php  }?>

    </tbody>
  </table>
</div>
   </body>
  </html>
