<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Employee_model extends CI_Model
 {
    public function saveEmployee($data)
  	 {
  		  $this->db->insert('empolyee',$data);   // Inserting data in employee table

                         //Insert id in $empid variable
  	 }

    public function fetch_data()
    {
     $query=$this->db->query("select * from empolyee");    //its a string

     $result = $query->result_array();
     return $result;

    }

    public function update_data()
    {
      $data = array(
                      'address' => 'London',
                      'empname'  => 'Vinaya',

                  );

      $this->db->where('empid','4');
      $this->db->update('empolyee',$data);
    }

    public function delete_data()
    {
      $this->db->where('empid', '2');
      $this->db->delete('empolyee');
    }

  }

?>
