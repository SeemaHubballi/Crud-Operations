<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Employee extends CI_Controller
{
  public function __construct()
  {
    parent::__construct();
    $this->load->model('employee_model');
  }


	public function index()
	{
                $this->load->helper('form');
		$this->load->view('employee_form');

	}

  public function employee_form()
  {
    //print_r($_POST);
    $save=array(   
 		    'empid'=>$this->input->post('empid'),
                    'empname'=>$this->input->post('empname'),
                    'email'=>$this->input->post('email'),
                    'phno'=>$this->input->post('phno'),
                    'address'=>$this->input->post('address'),
		    'doj'=>$this->input->post('doj')
              );
              $this->employee_model->saveEmployee($save);

            redirect('employee/get_data');



  }
  function get_data(){
       $getData['arrData'] = $this->employee_model->fetch_data();
       $this->load->view('employee',$getData);

  }

function change_data()
{
    $this->employee_model->update_data();
   echo "Updated successfully";


}

function delete_data()
{
    $this->employee_model->delete_data();
   echo "Deleted successfully";
   

}


}

?>
